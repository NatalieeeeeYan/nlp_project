from setuptools import setup, find_packages
import numpy as np

setup(
    name='grade-school-math',
    packages=find_packages(),
    version='0.0.1',
)