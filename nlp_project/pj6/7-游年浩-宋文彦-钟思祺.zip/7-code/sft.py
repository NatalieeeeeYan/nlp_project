import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
from torch.utils.data import Dataset, random_split
import json
import argparse


# 定义数据集类
class MathDataset(Dataset):
    def __init__(self, data, tokenizer, dataset_name, max_length=512):
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.dataset_name = dataset_name.lower().strip()
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        if 'math' in self.dataset_name:
            question = item['problem']
            solution = item['solution'] 
        elif 'gsm8k' in self.dataset_name:
            question = item['question']
            solution = item['answer']
        else:
            raise ValueError(f"Unsupported dataset: {self.dataset_name}")
            
        # 构造输入文本：问题 + 解题步骤
        prompt = (
            f"Please solve the following math problem step by step:\n\n"
            f"Question: {question}\n\nSolution: {solution}\n"
        )
        
        # 对问题和答案进行编码
        inputs = self.tokenizer(prompt, truncation=True, padding='max_length', max_length=self.max_length, return_tensors="pt")
        labels = inputs.input_ids.clone()  # 使用输入文本作为标签

        # 忽略填充token的损失
        labels[labels == self.tokenizer.pad_token_id] = -100
        
        return {'input_ids': inputs['input_ids'].squeeze(), 'labels': labels.squeeze()}

if __name__ == '__main__': 
    parser = argparse.ArgumentParser(description="Run segmentation on test images")
    parser.add_argument('--model', type=str, help='Path to the model.') 
    parser.add_argument('--dataset', type=str, help='Path to the dataset.') 
    parser.add_argument('--output', type=str, help='Path to save the trained model.') 
    args = parser.parse_args()

    # 加载模型和分词器
    model_name = args.model.split('/')[-1]
    model_path = args.model
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForCausalLM.from_pretrained(model_path, torch_dtype="auto", device_map="auto")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    print(f"Using device: {device}")
    print(f"Model {model_path} loaded successfully!")


    # 加载训练数据
    data = []
    with open(args.dataset, 'r') as f:
        for line in f:
            data.append(json.loads(line))

    # 创建数据集并划分为训练集和验证集
    dataset = MathDataset(data, tokenizer, dataset_name=args.dataset)
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

    # 设置训练参数
    training_args = TrainingArguments(
        output_dir=args.output,  # 模型保存路径
        evaluation_strategy="epoch",  # 每个epoch后评估一次
        learning_rate=5e-6,  # 学习率
        per_device_train_batch_size=4, 
        per_device_eval_batch_size=4,
        num_train_epochs=5, 
        save_strategy="epoch",  # 每个epoch后保存模型
        save_total_limit=2,  # 最多保存2个检查点
        report_to="none",  # 禁用默认的日志记录工具
        load_best_model_at_end=True,  # 使用验证集表现最好的模型
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,  # 训练集
        eval_dataset=val_dataset,    # 验证集
        tokenizer=tokenizer,
    )
    print(f"len of training set: {len(trainer.train_dataset)}\tvalidation set: {len(trainer.eval_dataset)}")
    trainer.train()

    # 保存微调后的模型
    trainer.save_model(args.output)
    tokenizer.save_pretrained(args.output)
    print(f"Model fine-tuning completed and saved at {args.output}.")

