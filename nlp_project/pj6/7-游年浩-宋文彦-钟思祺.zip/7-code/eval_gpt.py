import openai  
import json  

# 设置API密钥
# FIXME: 填补上OpenAI API密钥

def check_consistency(ground_truth, prediction):  
    '''
    检查预测和真实值是否一致

    @param ground_truth: 真实值 (str)
    @param prediction: 预测值 (str)

    @return: 是否一致 (str)
    '''
    # 定义提示信息，用于发送给GPT-4以获取一致性检查  
    prompt = f"Ground Truth: {ground_truth}\nPrediction: {prediction}\nAre the prediction and the ground truth the same in terms of meaning and content? Answer with 'Yes' or 'No'."  

    response = openai.ChatCompletion.create(  
      model="gpt-3.5-turbo",  # 指定使用GPT-3.5模型  
      messages=[  
          {"role": "system", "content": "You are a helpful assistant."},  
          {"role": "user", "content": prompt}  
      ],  
      max_tokens=10,  
      temperature=0.0  
    )  
    
    # 获取回答中的文本  
    answer = response['choices'][0]['message']['content'].strip()  
    return answer.lower() == 'yes'  


def process_file(file_path):  
    '''
    打开文件，逐行处理

    @param file_path: 文件路径 (str)

    @return: None
    '''
    with open(file_path, 'r', encoding='utf-8') as f:  
        for line in f:  
            item = json.loads(line)  
            ground_truth = item.get('groundTruth')  
            prediction = item.get('prediction')  
            
            if not ground_truth or not prediction:  
                print("Missing ground truth or prediction in line, skipping...")  
                continue  
            
            is_consistent = check_consistency(ground_truth, prediction)  
            print(f"Ground Truth: {ground_truth}\nPrediction: {prediction}\nConsistent: {is_consistent}\n")  


if __name__ == "__main__":  
    jsonl_file_path = './math500-Qwen2.5-Math-1.5B.jsonl'  # FIXME：待评估的模型输出路径
    process_file(jsonl_file_path)
